# EMC

Enhanced Monte Carlo\
https://montecarlo.sourceforge.net/emc/Welcome.html

EMC Download\
https://sourceforge.net/projects/montecarlo/files/emc_linux_fc31_v9.4.4_20220801.tgz/download

EMC UserForum\
https://matsci.org/c/emc/

P.J. in 't Veld and G.C. Rutledge, Macromolecules 2003, 36, 7358

